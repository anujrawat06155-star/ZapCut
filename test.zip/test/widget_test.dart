// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:zapcut/main.dart';

void main() {
  testWidgets('Zapcut opens on the video picker screen', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const ZapcutApp());

    expect(find.text('zapcut'), findsOneWidget);
    expect(find.text('Small edits.\nBig energy.'), findsOneWidget);
    expect(find.byKey(const ValueKey('choose-video')), findsOneWidget);
  });
}
