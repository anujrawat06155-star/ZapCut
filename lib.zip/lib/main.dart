import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/home_screen.dart';

const ink = Color(0xFF0B0D10);
const panel = Color(0xFF15181D);
const panelRaised = Color(0xFF1D2127);
const acid = Color(0xFFD8FF52);
const paper = Color(0xFFF4F5F0);
const muted = Color(0xFF92979F);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: ink,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ZapcutApp());
}

class ZapcutApp extends StatelessWidget {
  const ZapcutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zapcut',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: const ColorScheme.dark(
          primary: acid,
          onPrimary: ink,
          surface: panel,
          onSurface: paper,
          secondary: acid,
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: panelRaised,
          contentTextStyle: const TextStyle(color: paper),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
