package com.zapcut.zapcut

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
